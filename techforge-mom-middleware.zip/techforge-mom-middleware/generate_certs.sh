#!/bin/bash
# Script placeholder per generare certificati X.509
# Per ambienti reali usa OpenSSL

echo "Questo è solo un placeholder. Genera i tuoi certificati con OpenSSL:"
echo "  openssl req -x509 -newkey rsa:2048 -keyout key.pem -out cert.pem -days 365 -nodes"
